# Sort Everything V5

A mobile-first sorting puzzle prototype packaged as a simple Android WebView project.

## V5 upgrades
- Drag-and-drop plus tap controls
- Particle/confetti feedback and WebAudio feedback
- Freeze power-up using energy
- Lives + energy persistence
- Combo/scoring polish
- 100 levels, daily challenge, skins, achievements
- LocalStorage persistence

## Build
Open in Android Studio and build the `app` module. The project is intentionally dependency-light.

## Test
Run `node test-game.mjs` to validate the 100-level data model.
