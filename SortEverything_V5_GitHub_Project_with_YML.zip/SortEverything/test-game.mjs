const TYPES=[['🍎','Apple'],['🍋','Lemon'],['🍇','Grape'],['🍒','Cherry'],['🥝','Kiwi'],['🍊','Orange']];
for(let level=1;level<=100;level++){const n=Math.min(6,3+Math.ceil(level/8)),cap=Math.min(5,3+Math.floor((level-1)/25));if(n<3||n>6||cap<3||cap>5)throw Error('bad config');const a=[];for(let t=0;t<n;t++)for(let j=0;j<cap;j++)a.push({id:`${t}-${j}`,type:t});if(a.length!==n*cap)throw Error('count');if(new Set(a.map(x=>x.id)).size!==a.length)throw Error('duplicate');if(a.some(x=>x.type<0||x.type>=n))throw Error('type')}
console.log('PASS: 100-level data/config checks');
